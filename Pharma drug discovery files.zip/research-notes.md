# Project Meridian — Research Notes

**Program:** Meridian · **Lead:** NPX-2137 · **Target:** WRN helicase
**Indication:** MSI-high solid tumors · **Stage:** Lead optimization
**Prepared by:** Newpage for Pharma Client #001 · **Rev:** 1.2 · 2026-07-17

> ⚠️ **Simulated data.** NPX-2137, Project Meridian and Pharma Client #001 are
> fictional. All values below are illustrative and were generated for a
> role-play exercise. Nothing here represents real experimental results.

---

## 1. Hypothesis

Microsatellite-instability-high (MSI-H) cancers arise from defective DNA
mismatch repair (dMMR) and accumulate expanded `(TA)n` dinucleotide repeats.
During replication these repeats form secondary structures that **require the
WRN helicase to resolve**. MSI-H cells are therefore *synthetic-lethal* dependent
on WRN, whereas microsatellite-stable (MSS) cells are not.

**Therapeutic hypothesis:** a selective small-molecule WRN inhibitor will kill
MSI-H tumor cells while sparing MSS tissue, with MSI status (already standard
of care) serving as a ready-made patient-selection biomarker.

## 2. Discovery cascade

| Stage                | Method                                   | Outcome                          |
|----------------------|------------------------------------------|----------------------------------|
| Target validation    | 3 orthogonal CRISPR dropout screens      | WRN = top MSI-H-selective hit    |
| Hit identification   | 320k-compound HTS, WRN ATPase FRET assay | 1.2% hit rate; 4 chemotypes      |
| Hit-to-lead          | SPR + X-ray of the allosteric pocket     | pyrimidine series prioritized    |
| Lead optimization    | structure-based design, DMPK triage      | **NPX-2137** (current lead)      |

## 3. Mechanism of action

1. NPX-2137 binds an **allosteric pocket in the WRN ATPase domain** (not the
   ATP site) and locks the enzyme in a catalytically inactive conformation.
2. In MSI-H cells, WRN inhibition leaves `(TA)n` secondary structures
   unresolved → replication-fork collapse → **double-strand breaks (DSBs)**.
3. DSBs trigger the DNA-damage response (↑γH2AX, ↑pRPA32) and ultimately
   **apoptosis** (↑cleaved PARP, ↑sub-G1).
4. MSS cells do not depend on WRN, so replication proceeds normally — the basis
   of the therapeutic window.

## 4. Key results (see `data/` and the Discovery Report)

- **Biochemistry:** WRN ATPase IC50 = **42 nM**, DNA-unwinding IC50 = 58 nM,
  Hill ≈ 1 (monophasic, well-behaved). >470× selective over BLM / RECQ1 / RECQ5.
- **Cellular:** MSI-H GI50 0.11–0.19 µM; MSS lines >10 µM (**>90× window**).
  HCT116 **WRN-KO** cells are insensitive → confirms on-target killing.
- **Biomarkers (HCT116, 0.5 µM, 24 h):** γH2AX 6.4×, pRPA32 4.1×,
  cleaved PARP 5.8×, sub-G1 38%.
- **DMPK:** solubility 62 µM, MDCK Papp 18e-6 cm/s, HLM CLint 12 µL/min/mg,
  PPB 94%, hERG >30 µM, CYP >10 µM, Ames/micronucleus negative.
- **Rat PK (5 mpk PO):** Cmax 480 ng/mL, t½ 4.6 h, CL 22 mL/min/kg, **F = 58%**.
- **In vivo (HCT116 xenograft, QD PO ×21 d):** 25 mpk → 61% TGI;
  **50 mpk → 82% TGI**, well tolerated (<5% body-weight change).

## 5. SAR highlights (pyrimidine series)

- 2-aminopyrimidine hinge-mimetic is essential; N-methyl on the core costs ~10×.
- Meta-**methylsulfonyl aniline** drives the WRN selectivity vs BLM.
- Para-F benzamide on the piperazine improves metabolic stability (↓HLM CLint).
- cLogP sweet spot 2.5–3.2 balances permeability and clearance.

## 6. Open questions / next experiments

- [ ] Human hepatocyte clearance → human dose projection & PK/PD model.
- [ ] Free-fraction coverage: confirm unbound Cmin > cellular GI50 given 94% PPB.
- [ ] P-gp substrate assessment and CNS penetration (Kp,uu).
- [ ] Resistance modeling (WRN reactivation, bypass pathways) + combos
      (e.g. ATR inhibitor, anti-PD-1 given MSI-H immunogenicity).
- [ ] Nominate 1 backup chemotype for IND-enabling redundancy.

## 7. References / provenance

- Target biology grounded in the published MSI-H / WRN synthetic-lethality
  literature (Behan 2019; Chan 2019; Kategaya 2019; Lieb 2019 and follow-ups).
- All NPX-2137 numbers are **synthetic** — see `data/*.csv` for the source
  values and `scripts/` for the analysis that reproduces the report figures.
