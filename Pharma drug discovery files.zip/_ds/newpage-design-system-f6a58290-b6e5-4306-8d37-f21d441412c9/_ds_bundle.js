/* @ds-bundle: {"format":4,"namespace":"NewpageDesignSystem_f6a582","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"StatBlock","sourcePath":"components/data/StatBlock.jsx"},{"name":"StepCard","sourcePath":"components/data/StepCard.jsx"},{"name":"Accordion","sourcePath":"components/disclosure/Accordion.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Card","sourcePath":"components/surfaces/Card.jsx"},{"name":"ServiceCard","sourcePath":"components/surfaces/ServiceCard.jsx"},{"name":"TestimonialCard","sourcePath":"components/surfaces/TestimonialCard.jsx"},{"name":"SectionHeading","sourcePath":"components/typography/SectionHeading.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"0d93add368ac","components/core/Button.jsx":"5db48e0b5bc5","components/core/Tag.jsx":"d96045b6b486","components/data/StatBlock.jsx":"8b3f1adf7ab5","components/data/StepCard.jsx":"5ef19779f620","components/disclosure/Accordion.jsx":"bc3532a5f223","components/forms/Input.jsx":"22d26ca9c449","components/surfaces/Card.jsx":"f1ceb15913a7","components/surfaces/ServiceCard.jsx":"d1e56a9bf4af","components/surfaces/TestimonialCard.jsx":"624870022aa3","components/typography/SectionHeading.jsx":"edb4501faae8","ui_kits/website/App.jsx":"62b8818f6fd0","ui_kits/website/Footer.jsx":"d9959c1505bb","ui_kits/website/Header.jsx":"92fc20484a1e","ui_kits/website/HomePage.jsx":"b6fce8cbc1fc","ui_kits/website/Pages.jsx":"2df01984d4ba","ui_kits/website/Sections.jsx":"b90ab628afa9"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.NewpageDesignSystem_f6a582 = window.NewpageDesignSystem_f6a582 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Status badge — filled dot-pill for state (e.g. "Hiring!", "New", "Net Zero"). */
function Badge({
  children,
  tone = 'success',
  dot = false,
  style = {},
  ...rest
}) {
  const tones = {
    success: {
      background: 'var(--color-success-subtle)',
      color: 'var(--color-success)'
    },
    warning: {
      background: 'var(--color-warning-subtle)',
      color: 'var(--amber-700, #a9720b)'
    },
    danger: {
      background: 'var(--color-danger-subtle)',
      color: 'var(--color-danger)'
    },
    info: {
      background: 'var(--color-info-subtle)',
      color: 'var(--color-info)'
    },
    brand: {
      background: 'var(--teal-50)',
      color: 'var(--teal-700)'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '6px',
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-medium)',
      fontSize: '12px',
      lineHeight: 1.2,
      padding: '4px 10px',
      borderRadius: 'var(--radius-pill)',
      ...tones[tone],
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: '6px',
      height: '6px',
      borderRadius: '50%',
      background: 'currentColor'
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
/**
 * Newpage Button — pill-shaped, Roboto-bold. Primary is solid teal;
 * secondary is a teal outline; ghost is text-only. Optional up-right arrow.
 */
function Button({
  children,
  variant = 'primary',
  size = 'md',
  arrow = false,
  disabled = false,
  as = 'button',
  href,
  onClick,
  type = 'button',
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '9px 18px',
      fontSize: '14px'
    },
    md: {
      padding: '13px 26px',
      fontSize: '15px'
    },
    lg: {
      padding: '17px 34px',
      fontSize: '17px'
    }
  };
  const variants = {
    primary: {
      background: 'var(--brand-teal)',
      color: 'var(--color-on-primary)',
      border: '2px solid var(--brand-teal)'
    },
    secondary: {
      background: 'transparent',
      color: 'var(--teal-700)',
      border: '2px solid var(--brand-teal)'
    },
    dark: {
      background: 'var(--neutral-900)',
      color: 'var(--neutral-0)',
      border: '2px solid var(--neutral-900)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--teal-700)',
      border: '2px solid transparent'
    }
  };
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '10px',
    fontFamily: 'var(--font-sans)',
    fontWeight: 'var(--fw-bold)',
    lineHeight: 1,
    borderRadius: 'var(--radius-pill)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    textDecoration: 'none',
    whiteSpace: 'nowrap',
    transition: 'background var(--dur-base) var(--ease-standard), color var(--dur-base) var(--ease-standard), transform var(--dur-fast) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard)',
    ...sizes[size],
    ...variants[variant],
    ...style
  };
  const Tag = as === 'a' || href ? 'a' : 'button';
  const props = Tag === 'a' ? {
    href,
    onClick,
    style: base,
    ...rest
  } : {
    type,
    disabled,
    onClick,
    style: base,
    ...rest
  };
  return /*#__PURE__*/React.createElement(Tag, props, children, arrow && /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M7 17L17 7M17 7H8M17 7V16",
    stroke: "currentColor",
    strokeWidth: "2.4",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Category / topic tag — small uppercase pill used on case studies, blogs and filters. */
function Tag({
  children,
  tone = 'teal',
  size = 'md',
  style = {},
  ...rest
}) {
  const tones = {
    teal: {
      background: 'var(--teal-50)',
      color: 'var(--teal-700)'
    },
    yellow: {
      background: 'var(--yellow-100)',
      color: 'var(--yellow-700)'
    },
    orange: {
      background: 'var(--orange-100)',
      color: 'var(--orange-700)'
    },
    neutral: {
      background: 'var(--neutral-100)',
      color: 'var(--neutral-600)'
    },
    solid: {
      background: 'var(--brand-teal)',
      color: 'var(--neutral-0)'
    }
  };
  const sizes = {
    sm: {
      padding: '3px 9px',
      fontSize: '11px'
    },
    md: {
      padding: '5px 12px',
      fontSize: '12px'
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--fw-medium)',
      letterSpacing: 'var(--ls-wide)',
      textTransform: 'uppercase',
      borderRadius: 'var(--radius-pill)',
      lineHeight: 1.2,
      ...sizes[size],
      ...tones[tone],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/StatBlock.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Big-number stat block — the "200+ / Projects delivered" metrics on the homepage. */
function StatBlock({
  value,
  label,
  accent = 'teal',
  align = 'left',
  style = {},
  ...rest
}) {
  const accents = {
    teal: 'var(--brand-teal)',
    yellow: 'var(--brand-yellow)',
    orange: 'var(--brand-orange)',
    dark: 'var(--neutral-900)'
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-2)',
      textAlign: align,
      alignItems: align === 'center' ? 'center' : 'flex-start',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--fw-black)',
      fontSize: 'var(--fs-display)',
      lineHeight: 1,
      letterSpacing: 'var(--ls-tight)',
      color: accents[accent]
    }
  }, value), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-body)',
      color: 'var(--text-secondary)',
      lineHeight: 'var(--lh-snug)',
      maxWidth: '18ch'
    }
  }, label));
}
Object.assign(__ds_scope, { StatBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StatBlock.jsx", error: String((e && e.message) || e) }); }

// components/data/StepCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Numbered process step — the "01 Contact us" engagement flow cards. */
function StepCard({
  number,
  title,
  description,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-3)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 'var(--fw-black)',
      fontSize: 'var(--fs-h2)',
      lineHeight: 1,
      color: 'var(--brand-teal)'
    }
  }, String(number).padStart(2, '0')), /*#__PURE__*/React.createElement("h4", {
    style: {
      margin: 0,
      fontSize: 'var(--fs-h4)',
      fontWeight: 'var(--fw-bold)',
      fontFamily: 'var(--font-display)',
      color: 'var(--text-primary)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--fs-body)',
      lineHeight: 'var(--lh-body)',
      color: 'var(--text-secondary)'
    }
  }, description));
}
Object.assign(__ds_scope, { StepCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StepCard.jsx", error: String((e && e.message) || e) }); }

// components/disclosure/Accordion.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** FAQ-style disclosure list. Controlled internally; single-open by default. */
function Accordion({
  items = [],
  allowMultiple = false,
  style = {},
  ...rest
}) {
  const [open, setOpen] = React.useState(() => new Set());
  const toggle = i => {
    setOpen(prev => {
      const next = new Set(allowMultiple ? prev : []);
      if (prev.has(i)) next.delete(i);else next.add(i);
      return next;
    });
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      ...style
    }
  }, rest), items.map((item, i) => {
    const isOpen = open.has(i);
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        borderBottom: '1px solid var(--border-subtle)'
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => toggle(i),
      style: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: '16px',
        width: '100%',
        textAlign: 'left',
        cursor: 'pointer',
        background: 'none',
        border: 'none',
        padding: '20px 4px',
        fontFamily: 'var(--font-display)',
        fontSize: 'var(--fs-h4)',
        fontWeight: 'var(--fw-bold)',
        color: 'var(--text-primary)'
      }
    }, /*#__PURE__*/React.createElement("span", null, item.question), /*#__PURE__*/React.createElement("span", {
      style: {
        flexShrink: 0,
        width: '28px',
        height: '28px',
        borderRadius: '50%',
        background: isOpen ? 'var(--brand-teal)' : 'var(--teal-50)',
        color: isOpen ? '#fff' : 'var(--teal-700)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        transition: 'background var(--dur-base) var(--ease-standard), transform var(--dur-base) var(--ease-standard)',
        transform: isOpen ? 'rotate(45deg)' : 'none'
      }
    }, /*#__PURE__*/React.createElement("svg", {
      width: "14",
      height: "14",
      viewBox: "0 0 24 24",
      fill: "none"
    }, /*#__PURE__*/React.createElement("path", {
      d: "M12 5v14M5 12h14",
      stroke: "currentColor",
      strokeWidth: "2.4",
      strokeLinecap: "round"
    })))), /*#__PURE__*/React.createElement("div", {
      style: {
        maxHeight: isOpen ? '600px' : '0',
        overflow: 'hidden',
        transition: 'max-height var(--dur-slow) var(--ease-standard)'
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        padding: '0 4px 22px',
        fontSize: 'var(--fs-body)',
        lineHeight: 'var(--lh-body)',
        color: 'var(--text-secondary)'
      }
    }, item.answer)));
  }));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/disclosure/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Text input with optional label — brand focus ring in teal. */
function Input({
  label,
  hint,
  error,
  id,
  style = {},
  containerStyle = {},
  ...rest
}) {
  const inputId = id || (label ? `in-${String(label).replace(/\s+/g, '-').toLowerCase()}` : undefined);
  const [focused, setFocused] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px',
      ...containerStyle
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontSize: 'var(--fs-sm)',
      fontWeight: 'var(--fw-medium)',
      color: 'var(--text-primary)'
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    onFocus: e => {
      setFocused(true);
      rest.onFocus && rest.onFocus(e);
    },
    onBlur: e => {
      setFocused(false);
      rest.onBlur && rest.onBlur(e);
    },
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: 'var(--fs-body)',
      color: 'var(--text-primary)',
      padding: '12px 14px',
      background: 'var(--surface-page)',
      border: `1px solid ${error ? 'var(--color-danger)' : focused ? 'var(--brand-teal)' : 'var(--border-default)'}`,
      borderRadius: 'var(--radius-md)',
      outline: 'none',
      boxShadow: focused ? '0 0 0 3px var(--focus-ring)' : 'none',
      transition: 'border-color var(--dur-base) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, rest)), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-xs)',
      color: error ? 'var(--color-danger)' : 'var(--text-muted)'
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Generic elevated surface. Newpage cards are white, softly rounded, subtle shadow. */
function Card({
  children,
  elevation = 'sm',
  padded = true,
  hover = false,
  style = {},
  ...rest
}) {
  const shadows = {
    none: 'none',
    sm: 'var(--shadow-sm)',
    md: 'var(--shadow-md)',
    lg: 'var(--shadow-lg)'
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: hover ? e => {
      e.currentTarget.style.boxShadow = 'var(--shadow-lg)';
      e.currentTarget.style.transform = 'translateY(-4px)';
    } : undefined,
    onMouseLeave: hover ? e => {
      e.currentTarget.style.boxShadow = shadows[elevation];
      e.currentTarget.style.transform = 'none';
    } : undefined,
    style: {
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: shadows[elevation],
      padding: padded ? 'var(--space-6)' : 0,
      transition: 'box-shadow var(--dur-base) var(--ease-standard), transform var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/Card.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/ServiceCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Service card — the dark tiles on the Newpage homepage: a media/icon block,
 * a title, a short description and an up-right arrow. Whole card is a link.
 */
function ServiceCard({
  title,
  description,
  media,
  href,
  tone = 'dark',
  style = {},
  ...rest
}) {
  const dark = tone === 'dark';
  return /*#__PURE__*/React.createElement("a", _extends({
    href: href,
    onMouseEnter: e => {
      e.currentTarget.style.transform = 'translateY(-6px)';
      e.currentTarget.style.boxShadow = 'var(--shadow-lg)';
    },
    onMouseLeave: e => {
      e.currentTarget.style.transform = 'none';
      e.currentTarget.style.boxShadow = 'var(--shadow-sm)';
    },
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-5)',
      textDecoration: 'none',
      background: dark ? 'var(--neutral-900)' : 'var(--surface-card)',
      color: dark ? 'var(--neutral-0)' : 'var(--text-primary)',
      border: dark ? '1px solid var(--neutral-800)' : '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      padding: 'var(--space-6)',
      boxShadow: 'var(--shadow-sm)',
      transition: 'transform var(--dur-base) var(--ease-standard), box-shadow var(--dur-base) var(--ease-standard)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
      gap: '16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '56px',
      height: '56px',
      borderRadius: 'var(--radius-md)',
      background: dark ? 'rgba(8,189,184,.16)' : 'var(--teal-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, media), /*#__PURE__*/React.createElement("span", {
    style: {
      width: '40px',
      height: '40px',
      borderRadius: '50%',
      background: 'var(--brand-teal)',
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M7 17L17 7M17 7H8M17 7V16",
    stroke: "currentColor",
    strokeWidth: "2.4",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })))), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 'var(--fs-h4)',
      fontWeight: 'var(--fw-bold)',
      fontFamily: 'var(--font-display)',
      lineHeight: 'var(--lh-heading)'
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--fs-body)',
      lineHeight: 'var(--lh-body)',
      color: dark ? 'var(--neutral-300)' : 'var(--text-secondary)'
    }
  }, description));
}
Object.assign(__ds_scope, { ServiceCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/ServiceCard.jsx", error: String((e && e.message) || e) }); }

// components/surfaces/TestimonialCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Testimonial / quote card with the Newpage brand quote mark, body, and attribution. */
function TestimonialCard({
  quote,
  name,
  role,
  avatar,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("figure", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-6)',
      background: 'var(--surface-card)',
      border: '1px solid var(--border-subtle)',
      borderRadius: 'var(--radius-lg)',
      boxShadow: 'var(--shadow-md)',
      padding: 'var(--space-10)',
      margin: 0,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("svg", {
    width: "52",
    height: "40",
    viewBox: "0 0 52 40",
    fill: "none",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M0 40V22C0 9.85 8.4 1.2 21 0L23 6.5C15.2 8 11 12.4 11 18h9v22H0Zm29 0V22C29 9.85 37.4 1.2 50 0l2 6.5C44.2 8 40 12.4 40 18h9v22H29Z",
    fill: "var(--brand-teal)"
  })), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-h4)',
      fontWeight: 'var(--fw-regular)',
      lineHeight: 'var(--lh-snug)',
      color: 'var(--text-primary)'
    }
  }, quote), /*#__PURE__*/React.createElement("figcaption", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 'var(--space-4)',
      marginTop: 'auto'
    }
  }, avatar && /*#__PURE__*/React.createElement("img", {
    src: avatar,
    alt: "",
    style: {
      width: '52px',
      height: '52px',
      borderRadius: '50%',
      objectFit: 'cover'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontWeight: 'var(--fw-bold)',
      color: 'var(--text-primary)',
      fontSize: 'var(--fs-body)'
    }
  }, name), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 'var(--fs-sm)'
    }
  }, role))));
}
Object.assign(__ds_scope, { TestimonialCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/surfaces/TestimonialCard.jsx", error: String((e && e.message) || e) }); }

// components/typography/SectionHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Section heading — the eyebrow + big title + optional lead used to open sections.
 * Eyebrow shows a short teal bar and uppercase label.
 */
function SectionHeading({
  eyebrow,
  title,
  lead,
  align = 'left',
  onDark = false,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 'var(--space-4)',
      alignItems: align === 'center' ? 'center' : 'flex-start',
      textAlign: align,
      maxWidth: '760px',
      marginInline: align === 'center' ? 'auto' : undefined,
      ...style
    }
  }, rest), eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: '28px',
      height: '3px',
      borderRadius: '2px',
      background: 'var(--brand-teal)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'var(--fs-eyebrow)',
      fontWeight: 'var(--fw-bold)',
      letterSpacing: 'var(--ls-eyebrow)',
      textTransform: 'uppercase',
      color: 'var(--teal-600)'
    }
  }, eyebrow)), /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontFamily: 'var(--font-display)',
      fontSize: 'var(--fs-h2)',
      fontWeight: 'var(--fw-bold)',
      lineHeight: 'var(--lh-heading)',
      letterSpacing: 'var(--ls-tight)',
      color: onDark ? 'var(--neutral-0)' : 'var(--text-primary)',
      textWrap: 'balance'
    }
  }, title), lead && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'var(--fs-lead)',
      lineHeight: 'var(--lh-body)',
      color: onDark ? 'var(--neutral-300)' : 'var(--text-secondary)'
    }
  }, lead));
}
Object.assign(__ds_scope, { SectionHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/typography/SectionHeading.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/App.jsx
try { (() => {
function App() {
  const [page, setPage] = React.useState('home');
  const scrollRef = React.useRef(null);
  const onNav = p => {
    setPage(p);
    const el = document.getElementById('kit-scroll');
    if (el) el.scrollTop = 0;
  };
  React.useEffect(() => {
    window.lucide && window.lucide.createIcons();
  });
  let body;
  if (page === 'home') body = /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(window.HomePage, {
    onNav: onNav
  }), /*#__PURE__*/React.createElement(window.Testimonials, null), /*#__PURE__*/React.createElement(window.Engage, {
    onNav: onNav
  }), /*#__PURE__*/React.createElement(window.Faqs, null));else if (page === 'services') body = /*#__PURE__*/React.createElement(window.ServicesPage, null);else if (page === 'contact') body = /*#__PURE__*/React.createElement(window.ContactPage, null);else if (page === 'cases') body = /*#__PURE__*/React.createElement(window.SimplePage, {
    eyebrow: "Case studies",
    title: "Outcomes across pharma, biotech & healthcare",
    lead: "Browse how we've delivered AI, marketing technology and digital health solutions for global life-sciences leaders."
  });else if (page === 'insights') body = /*#__PURE__*/React.createElement(window.SimplePage, {
    eyebrow: "Insights",
    title: "Blogs, announcements & papers",
    lead: "Perspectives from our engineers on AI delivery, compliance and digital health."
  });else if (page === 'careers') body = /*#__PURE__*/React.createElement(window.SimplePage, {
    eyebrow: "Careers",
    title: "Build breakthroughs with us",
    lead: "We're a remote-first, distributed team across 10 countries. Hiring across engineering, AI and delivery."
  });else body = /*#__PURE__*/React.createElement(window.SimplePage, {
    eyebrow: "About us",
    title: "A trusted life-sciences technology partner",
    lead: "We challenge the conventional approach to technology adoption, championing innovation to solve complex problems for pharma and biotech."
  });
  const dark = page === 'home';
  return /*#__PURE__*/React.createElement("div", {
    id: "kit-scroll",
    ref: scrollRef,
    style: {
      height: '100vh',
      overflowY: 'auto',
      background: '#fff'
    }
  }, /*#__PURE__*/React.createElement(window.Header, {
    page: page,
    onNav: onNav,
    dark: dark
  }), body, /*#__PURE__*/React.createElement(window.Footer, {
    onNav: onNav
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
setTimeout(() => window.lucide && window.lucide.createIcons(), 60);
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
const {
  Button
} = window.NewpageDesignSystem_f6a582;
const COLS = [{
  h: 'Company',
  links: ['Services', 'Insights', 'Case Studies', 'About us', 'Careers', 'Contact us']
}, {
  h: 'Services',
  links: ['Data & AI', 'Marketing Technologies', 'Digital Health', 'Technical Services', 'NAT Studio']
}];
function Footer({
  onNav
}) {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--neutral-900)',
      color: 'var(--neutral-300)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '72px 24px 40px',
      display: 'grid',
      gridTemplateColumns: '1.4fr 1fr 1fr 1.2fr',
      gap: '40px'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-white.svg",
    alt: "Newpage",
    style: {
      height: '28px',
      marginBottom: '16px'
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: '14px',
      lineHeight: 1.7,
      maxWidth: '30ch'
    }
  }, "Digital & connected health solutions for life-sciences organizations worldwide."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '10px',
      marginTop: '20px'
    }
  }, ['linkedin', 'twitter'].map(s => /*#__PURE__*/React.createElement("span", {
    key: s,
    style: {
      width: '38px',
      height: '38px',
      borderRadius: '50%',
      border: '1px solid rgba(255,255,255,.18)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": s,
    style: {
      width: 16,
      height: 16,
      color: '#fff'
    }
  }))))), COLS.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.h
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '13px',
      fontWeight: 700,
      letterSpacing: '.12em',
      textTransform: 'uppercase',
      color: '#fff',
      marginBottom: '16px'
    }
  }, c.h), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: 'none',
      margin: 0,
      padding: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: '10px'
    }
  }, c.links.map(l => /*#__PURE__*/React.createElement("li", {
    key: l
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav && onNav('home');
    },
    style: {
      color: 'var(--neutral-300)',
      textDecoration: 'none',
      fontSize: '14px'
    }
  }, l)))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '13px',
      fontWeight: 700,
      letterSpacing: '.12em',
      textTransform: 'uppercase',
      color: '#fff',
      marginBottom: '16px'
    }
  }, "Get in touch"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 6px',
      fontSize: '14px'
    }
  }, "info@newpage.io"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 16px',
      fontSize: '14px',
      lineHeight: 1.6
    }
  }, "601 Brickell Key Drive, Suite 700", /*#__PURE__*/React.createElement("br", null), "Miami, Florida 33131"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    arrow: true,
    onClick: () => onNav && onNav('contact')
  }, "Contact us"))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: '1px solid rgba(255,255,255,.1)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '20px 24px',
      display: 'flex',
      justifyContent: 'space-between',
      flexWrap: 'wrap',
      gap: '12px',
      fontSize: '13px',
      color: 'var(--neutral-400)'
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA92026 Newpage.io \u2014 All rights reserved"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      gap: '20px'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault(),
    style: {
      color: 'var(--neutral-400)',
      textDecoration: 'none'
    }
  }, "Privacy Policy"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault(),
    style: {
      color: 'var(--neutral-400)',
      textDecoration: 'none'
    }
  }, "Terms & Conditions")))));
}
window.Footer = Footer;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Header.jsx
try { (() => {
const {
  Button
} = window.NewpageDesignSystem_f6a582;
const NAV = [{
  label: 'Services',
  page: 'services'
}, {
  label: 'Insights',
  page: 'insights'
}, {
  label: 'Case studies',
  page: 'cases'
}, {
  label: 'Careers',
  page: 'careers',
  badge: 'Hiring!'
}, {
  label: 'About us',
  page: 'about'
}];
function Header({
  page,
  onNav,
  dark
}) {
  const [scrolled, setScrolled] = React.useState(false);
  React.useEffect(() => {
    const el = document.getElementById('kit-scroll');
    const onScroll = () => setScrolled((el ? el.scrollTop : window.scrollY) > 12);
    (el || window).addEventListener('scroll', onScroll);
    return () => (el || window).removeEventListener('scroll', onScroll);
  }, []);
  const onDark = dark && !scrolled;
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 100,
      marginBottom: dark ? '-76px' : 0,
      background: onDark ? 'transparent' : 'rgba(255,255,255,.9)',
      backdropFilter: onDark ? 'none' : 'saturate(180%) blur(12px)',
      borderBottom: onDark ? '1px solid transparent' : '1px solid var(--border-subtle)',
      transition: 'background .3s, border-color .3s'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '0 24px',
      height: '76px',
      display: 'flex',
      alignItems: 'center',
      gap: '32px'
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav('home');
    },
    style: {
      display: 'flex',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: onDark ? '../../assets/logo-white.svg' : '../../assets/logo-black.svg',
    alt: "Newpage",
    style: {
      height: '26px'
    }
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      gap: '4px',
      marginLeft: '8px'
    }
  }, NAV.map(n => /*#__PURE__*/React.createElement("a", {
    key: n.label,
    href: "#",
    onClick: e => {
      e.preventDefault();
      onNav(n.page);
    },
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: '6px',
      padding: '8px 14px',
      borderRadius: '999px',
      textDecoration: 'none',
      fontSize: '15px',
      fontWeight: 500,
      color: page === n.page ? 'var(--teal-600)' : onDark ? 'rgba(255,255,255,.88)' : 'var(--text-primary)',
      background: page === n.page ? onDark ? 'rgba(255,255,255,.12)' : 'var(--teal-50)' : 'transparent',
      transition: 'background .2s, color .2s'
    }
  }, n.label, n.badge && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '10px',
      fontWeight: 700,
      color: '#fff',
      background: 'var(--brand-orange)',
      padding: '2px 6px',
      borderRadius: '999px'
    }
  }, n.badge)))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: onDark ? 'primary' : 'dark',
    size: "sm",
    arrow: true,
    onClick: () => onNav('contact')
  }, "Contact us"))));
}
window.Header = Header;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Header.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomePage.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  Button,
  SectionHeading,
  ServiceCard,
  StatBlock,
  Card,
  Tag
} = window.NewpageDesignSystem_f6a582;
function Icon({
  name,
  size = 24,
  color
}) {
  const ref = React.useRef(null);
  React.useEffect(() => {
    window.lucide && window.lucide.createIcons({
      nameAttr: 'data-lucide',
      icons: window.lucide.icons
    });
  });
  return /*#__PURE__*/React.createElement("i", {
    ref: ref,
    "data-lucide": name,
    style: {
      width: size,
      height: size,
      color
    }
  });
}
const SERVICES = [{
  icon: 'brain-circuit',
  title: 'Data & Artificial Intelligence',
  desc: 'Boost productivity across your organisation with scalable data and AI solutions.'
}, {
  icon: 'megaphone',
  title: 'Marketing Technologies',
  desc: 'Drive engagement with personalized experiences and omnichannel solutions.'
}, {
  icon: 'heart-pulse',
  title: 'Digital Health',
  desc: 'Engage and empower customers throughout their care journey.'
}, {
  icon: 'code-2',
  title: 'Technical Services',
  desc: 'Deep technology experience from development to deployment.'
}];
const STATS = [{
  value: '200+',
  label: 'Projects delivered',
  accent: 'teal'
}, {
  value: '27',
  label: 'Countries where our projects are deployed',
  accent: 'orange'
}, {
  value: '150K+',
  label: 'Hours on healthcare projects',
  accent: 'yellow'
}, {
  value: '10',
  label: 'Countries where our teams are located',
  accent: 'dark'
}];
const CASES = [{
  tags: ['AI/ML/Data', 'Salesforce'],
  title: 'Automating CRM Support Operations via AI Chatbot',
  desc: 'AI-powered Salesforce chatbot cut resolution times from four days to under five minutes.',
  c: 'linear-gradient(135deg,#08BDB8,#008C85)'
}, {
  tags: ['AI/ML/Data', 'Marketing'],
  title: 'From Weeks to Hours: How GenAI Transformed Brand Reporting',
  desc: 'Enterprise brand teams across 60+ brands escaped manual reporting with GenAI.',
  c: 'linear-gradient(135deg,#FFCF36,#FF7F1F)'
}, {
  tags: ['Digital Health', 'Mobile'],
  title: 'Augmented Reality for Immunity Education',
  desc: 'An interactive AR game that teaches children about the immune system.',
  c: 'linear-gradient(135deg,#2E3739,#0C1213)'
}];
function HomePage({
  onNav
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--neutral-900)',
      color: '#fff',
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'radial-gradient(900px 500px at 85% -10%, rgba(8,189,184,.28), transparent 60%)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '120px 24px 130px',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: '10px',
      marginBottom: '24px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: '28px',
      height: '3px',
      background: 'var(--brand-teal)',
      borderRadius: '2px'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '13px',
      fontWeight: 700,
      letterSpacing: '.14em',
      textTransform: 'uppercase',
      color: 'var(--teal-300)'
    }
  }, "Life Sciences \xB7 AI & Digital")), /*#__PURE__*/React.createElement("h1", {
    style: {
      margin: 0,
      fontSize: '64px',
      lineHeight: 1.04,
      fontWeight: 900,
      letterSpacing: '-.02em',
      maxWidth: '15ch'
    }
  }, "Deliver Breakthroughs with a trusted partner"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '24px 0 36px',
      fontSize: '20px',
      lineHeight: 1.6,
      color: 'var(--neutral-300)',
      maxWidth: '54ch'
    }
  }, "Transform your life sciences organization with AI & Digital solutions that drive innovation and productivity."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '16px',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    arrow: true,
    onClick: () => onNav('services')
  }, "Explore AI Solutions"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "lg",
    style: {
      color: '#fff',
      border: '2px solid rgba(255,255,255,.25)'
    },
    onClick: () => onNav('cases')
  }, "View case studies")))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '96px 24px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Services",
    title: "We drive technology transformation across pharma and biotech",
    style: {
      marginBottom: '48px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: '20px'
    }
  }, SERVICES.map(s => /*#__PURE__*/React.createElement(ServiceCard, {
    key: s.title,
    tone: "dark",
    href: "#",
    title: s.title,
    description: s.desc,
    media: /*#__PURE__*/React.createElement(Icon, {
      name: s.icon,
      color: "var(--brand-teal)"
    })
  })))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-subtle)',
      borderTop: '1px solid var(--border-subtle)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '72px 24px'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: '0 0 40px',
      fontSize: '26px',
      fontWeight: 700,
      lineHeight: 1.3,
      maxWidth: '30ch'
    }
  }, "A global team of problem-solvers with deep life-sciences expertise."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: '32px'
    }
  }, STATS.map(s => /*#__PURE__*/React.createElement(StatBlock, _extends({
    key: s.label
  }, s)))))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '96px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-end',
      marginBottom: '40px',
      gap: '24px',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Case studies",
    title: "Outcomes we're proud of"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    arrow: true,
    onClick: () => onNav('cases')
  }, "All case studies")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: '24px'
    }
  }, CASES.map(c => /*#__PURE__*/React.createElement(Card, {
    key: c.title,
    padded: false,
    hover: true,
    elevation: "sm",
    style: {
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '160px',
      background: c.c
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '20px',
      display: 'flex',
      flexDirection: 'column',
      gap: '12px',
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '6px',
      flexWrap: 'wrap'
    }
  }, c.tags.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    tone: "teal",
    size: "sm"
  }, t))), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: '19px',
      fontWeight: 700,
      lineHeight: 1.3
    }
  }, c.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: '14px',
      color: 'var(--text-secondary)',
      lineHeight: 1.6
    }
  }, c.desc), /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault(),
    style: {
      marginTop: 'auto',
      color: 'var(--teal-700)',
      fontWeight: 700,
      fontSize: '14px',
      textDecoration: 'none'
    }
  }, "Discover more \u2192")))))));
}
window.HomePage = HomePage;
window.KitIcon = Icon;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomePage.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Pages.jsx
try { (() => {
const {
  SectionHeading,
  ServiceCard,
  Input,
  Button,
  Card,
  Tag
} = window.NewpageDesignSystem_f6a582;
const KI = window.KitIcon;
const DETAIL = [{
  icon: 'brain-circuit',
  title: 'Data & Artificial Intelligence',
  desc: 'Scalable data and AI platforms — from LLM apps to computational pipelines.'
}, {
  icon: 'megaphone',
  title: 'Marketing Technologies',
  desc: 'Salesforce, Veeva and Adobe Experience Cloud personalization at scale.'
}, {
  icon: 'heart-pulse',
  title: 'Digital Health',
  desc: 'Companion apps, chronic disease management, and bioinformatics.'
}, {
  icon: 'code-2',
  title: 'Technical Services',
  desc: 'Mobile & web, cloud, microservices, DevOps, QA and AR/VR/XR.'
}, {
  icon: 'flask-conical',
  title: 'NAT Studio',
  desc: 'AI-powered test automation built for scale, stability and compliance.'
}, {
  icon: 'shield-check',
  title: 'Compliance & QA',
  desc: 'Validated, regulated delivery for pharma, biotech and BFSI.'
}];
function ServicesPage() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-subtle)',
      borderBottom: '1px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '80px 24px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Services",
    title: "Technology transformation for life sciences",
    lead: "We help drive technology transformation across the pharmaceutical and biotech industry \u2014 from ideation and strategy to design, development and delivery."
  }))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '72px 24px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: '20px'
    }
  }, DETAIL.map(s => /*#__PURE__*/React.createElement(ServiceCard, {
    key: s.title,
    tone: "light",
    href: "#",
    title: s.title,
    description: s.desc,
    media: /*#__PURE__*/React.createElement(KI, {
      name: s.icon,
      color: "var(--brand-teal)"
    })
  })))));
}
function ContactPage() {
  const [sent, setSent] = React.useState(false);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '80px 24px',
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '64px',
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Let's connect",
    title: "Tell us about your project",
    lead: "We'll get back to you within 2 business days."
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '20px',
      marginTop: '32px'
    }
  }, [['mail', 'info@newpage.io'], ['phone', '+1 910-420-0496'], ['map-pin', 'Miami · Bangalore · Chennai']].map(([ic, t]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      gap: '14px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: '44px',
      height: '44px',
      borderRadius: '12px',
      background: 'var(--teal-50)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(KI, {
    name: ic,
    color: "var(--teal-700)",
    size: 20
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '16px',
      color: 'var(--text-primary)'
    }
  }, t))))), /*#__PURE__*/React.createElement(Card, {
    elevation: "lg",
    style: {
      padding: '32px'
    }
  }, sent ? /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '64px',
      height: '64px',
      borderRadius: '50%',
      background: 'var(--color-success-subtle)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      margin: '0 auto 20px'
    }
  }, /*#__PURE__*/React.createElement(KI, {
    name: "check",
    color: "var(--color-success)",
    size: 30
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: '0 0 8px',
      fontSize: '22px',
      fontWeight: 700
    }
  }, "Thanks \u2014 we'll be in touch"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      color: 'var(--text-secondary)'
    }
  }, "Our team will reach out within 2 business days.")) : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      setSent(true);
    },
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: '16px'
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "First name",
    placeholder: "Jane",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Last name",
    placeholder: "Doe",
    required: true
  })), /*#__PURE__*/React.createElement(Input, {
    label: "Work email",
    type: "email",
    placeholder: "you@company.com",
    required: true
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Company",
    placeholder: "Acme Biotech"
  }), /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: '6px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: '14px',
      fontWeight: 500
    }
  }, "How can we help?"), /*#__PURE__*/React.createElement("textarea", {
    rows: "4",
    placeholder: "Tell us about your project",
    style: {
      fontFamily: 'var(--font-sans)',
      fontSize: '16px',
      padding: '12px 14px',
      border: '1px solid var(--border-default)',
      borderRadius: '10px',
      resize: 'vertical'
    }
  })), /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      gap: '10px',
      alignItems: 'flex-start',
      fontSize: '13px',
      color: 'var(--text-secondary)'
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    style: {
      marginTop: '3px'
    }
  }), " I agree to receive emails and marketing communications from Newpage."), /*#__PURE__*/React.createElement(Button, {
    type: "submit",
    variant: "primary",
    size: "lg",
    arrow: true,
    style: {
      width: '100%'
    }
  }, "Send message"))));
}
function SimplePage({
  title,
  eyebrow,
  lead
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: '900px',
      margin: '0 auto',
      padding: '110px 24px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: eyebrow,
    title: title,
    lead: lead,
    align: "center"
  }));
}
Object.assign(window, {
  ServicesPage,
  ContactPage,
  SimplePage
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Pages.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Sections.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const {
  SectionHeading,
  TestimonialCard,
  StepCard,
  Accordion,
  Button
} = window.NewpageDesignSystem_f6a582;
const QUOTES = [{
  quote: "As a strategic technology partner, Newpage brought deep technical expertise to accelerate the development of key digital capabilities, including a cloud-based computational psychiatry and data platform.",
  name: 'Pablo Gersberg',
  role: 'VP, BlackThorn Therapeutics'
}, {
  quote: "Newpage took the time to truly understand our goals, then clearly discussed plans and expectations. The team contributed crucial expertise to bring our vision to life.",
  name: 'Saquib Lakhani',
  role: 'Co-Founder, Victory Genomics'
}, {
  quote: "Their customized gene sequencing solution streamlined our workflow, enabling us to handle large-scale genomic data with precision and reliability.",
  name: 'Ahmed',
  role: 'R&D and Co-Founder, QIYAS'
}];
const STEPS = [{
  number: 1,
  title: 'Contact us',
  description: "Reach out via our form or phone—we'll respond promptly."
}, {
  number: 2,
  title: 'Understanding your goals',
  description: 'We listen to your objectives and craft an approach that aligns with your vision.'
}, {
  number: 3,
  title: 'Proposal presentation',
  description: "We develop a tailored proposal and roadmap to achieve your goals."
}, {
  number: 4,
  title: "We're partners!",
  description: 'Once finalized, our team begins the engagement, working alongside you as partners.'
}];
const FAQ = [{
  question: 'What is Newpage Solutions?',
  answer: 'A life-sciences digital engineering partner specialising in Salesforce/Veeva, Adobe Experience Cloud, AI/data engineering, custom software, cloud, and DevOps for pharma, biotech and regulated enterprises.'
}, {
  question: 'What services do you offer?',
  answer: 'Digital engineering, platform expertise (Salesforce Health Cloud, Veeva CRM, Adobe AEM), flexible delivery models (GCC/ODC, augmentation), and a compliant life-sciences vertical focus.'
}, {
  question: "What's the difference between ODC and GCC?",
  answer: 'An ODC provides dedicated teams for specific projects; a GCC is a client-owned hub for enterprise-wide functions. Newpage builds both and evolves ODCs into GCCs.'
}, {
  question: 'Are you Net Zero certified?',
  answer: 'Yes — Scope 1 & 2 Net Zero achieved (2025, verified baseline 2023). Sustainable remote-first engineering supports green digital transformation.'
}];
function Testimonials() {
  const [i, setI] = React.useState(0);
  const go = d => setI(p => (p + d + QUOTES.length) % QUOTES.length);
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--neutral-900)',
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '980px',
      margin: '0 auto',
      padding: '96px 24px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "Testimonials",
    title: "Trusted by life-sciences innovators",
    onDark: true,
    style: {
      marginBottom: '40px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      borderRadius: '20px'
    }
  }, /*#__PURE__*/React.createElement(TestimonialCard, QUOTES[i])), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '12px',
      marginTop: '24px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => go(-1),
    style: navBtn
  }, "\u2190"), /*#__PURE__*/React.createElement("button", {
    onClick: () => go(1),
    style: navBtn
  }, "\u2192"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: '8px',
      marginLeft: '8px'
    }
  }, QUOTES.map((_, k) => /*#__PURE__*/React.createElement("span", {
    key: k,
    onClick: () => setI(k),
    style: {
      width: k === i ? '24px' : '8px',
      height: '8px',
      borderRadius: '999px',
      background: k === i ? 'var(--brand-teal)' : 'rgba(255,255,255,.3)',
      cursor: 'pointer',
      transition: 'all .3s'
    }
  }))))));
}
const navBtn = {
  width: '44px',
  height: '44px',
  borderRadius: '50%',
  border: '1px solid rgba(255,255,255,.25)',
  background: 'transparent',
  color: '#fff',
  cursor: 'pointer',
  fontSize: '18px'
};

// Fix quote/author colours on dark
function TestimonialsDarkFix() {
  return null;
}
function Engage({
  onNav
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: '1200px',
      margin: '0 auto',
      padding: '96px 24px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "How to engage",
    title: "How to engage with us",
    align: "center",
    style: {
      marginBottom: '56px'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: '32px'
    }
  }, STEPS.map(s => /*#__PURE__*/React.createElement(StepCard, _extends({
    key: s.number
  }, s)))), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginTop: '48px'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    arrow: true,
    onClick: () => onNav('contact')
  }, "Contact us")));
}
function Faqs() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: 'var(--surface-subtle)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: '860px',
      margin: '0 auto',
      padding: '96px 24px'
    }
  }, /*#__PURE__*/React.createElement(SectionHeading, {
    eyebrow: "FAQ",
    title: "Frequently asked questions",
    style: {
      marginBottom: '32px'
    }
  }), /*#__PURE__*/React.createElement(Accordion, {
    items: FAQ
  })));
}
Object.assign(window, {
  Testimonials,
  Engage,
  Faqs
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Sections.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.StatBlock = __ds_scope.StatBlock;

__ds_ns.StepCard = __ds_scope.StepCard;

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.ServiceCard = __ds_scope.ServiceCard;

__ds_ns.TestimonialCard = __ds_scope.TestimonialCard;

__ds_ns.SectionHeading = __ds_scope.SectionHeading;

})();
