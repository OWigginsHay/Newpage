===============================================================================
 PROJECT MERIDIAN -- NPX-2137 Discovery Data Package
 Prepared by Newpage for Pharma Client #001
===============================================================================

*** SIMULATED / FICTIONAL DATA -- ROLE-PLAY SCENARIO ***
NPX-2137, "Project Meridian" and "Pharma Client #001" are not real. Every
number in this package is illustrative and was generated for demonstration.
Do not use for any real scientific, regulatory or clinical purpose.

-------------------------------------------------------------------------------
WHAT THIS IS
-------------------------------------------------------------------------------
A small, branded document set role-playing a new small-molecule drug-discovery
program: NPX-2137, an allosteric WRN-helicase inhibitor exploiting synthetic
lethality in microsatellite-instability-high (MSI-H) solid tumors.

-------------------------------------------------------------------------------
CONTENTS
-------------------------------------------------------------------------------
  Program Brief.dc.html      One-page branded program brief (export to PDF).
  Discovery Report.dc.html   Multi-page report with charts + data tables (PDF).
  Mechanism Graphic.dc.html  Standalone mechanism-of-action graphic (1600x1000;
                             export to PNG). Rendered copy in
                             assets/mechanism-of-action.png.

  research-notes.md          Structured research notes (hypothesis, cascade,
                             SAR, key results, open questions).
  lab-notes.txt              Dated lab-notebook excerpt.
  README.txt                 This file.

  data/assay_data.csv        Biochemical dose-response (WRN ATPase + unwinding),
                             tidy/long, 3 replicates.
  data/cell_potency.csv      Antiproliferative GI50 per cell line (MSI-H vs MSS).
  data/study_data.csv        Xenograft tumor volumes + rat PK, tidy/long.

  scripts/ic50_analysis.py   Fit 4-parameter-logistic curves; report IC50/Hill.
  scripts/plot_charts.py     Regenerate the report figures from data/ into
                             figures/*.png.
  scripts/smiles_utils.py    Molecular descriptors + Lipinski/Veber checks
                             (RDKit if available, curated fallback otherwise).

-------------------------------------------------------------------------------
RUNNING THE PYTHON
-------------------------------------------------------------------------------
Requirements:  python >= 3.9
               pip install numpy pandas scipy matplotlib
               (optional) pip install rdkit          # for smiles_utils.py

From the project root:

    python scripts/ic50_analysis.py            # prints IC50 / Hill / selectivity
    python scripts/ic50_analysis.py --plot     # + shows the fitted curves
    python scripts/plot_charts.py              # writes figures/fig1..4.png
    python scripts/smiles_utils.py             # profiles the lead, NPX-2137

Note: plot_charts.py imports ic50_analysis.py, so run the scripts from within
the scripts/ directory or with the repo root on PYTHONPATH, e.g.:

    cd scripts && python plot_charts.py

-------------------------------------------------------------------------------
THE .dc.html DOCUMENTS
-------------------------------------------------------------------------------
The three .dc.html files are self-contained, branded documents built on the
Newpage design system. Open them to view/edit; the two report documents are
print-ready (use the PDF export). The mechanism graphic is a fixed 1600x1000
canvas intended to be exported as an image.

Key numbers (all simulated):
  WRN ATPase IC50 ......... 42 nM
  MSI-H GI50 (mean) ....... 0.15 uM      MSS window ....... >90x
  Rat oral F .............. 58%          Xenograft TGI .... 82% (50 mg/kg QD)
