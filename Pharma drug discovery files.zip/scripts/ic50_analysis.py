#!/usr/bin/env python3
"""
ic50_analysis.py  --  Project Meridian / NPX-2137

Fit four-parameter-logistic (4PL) dose-response curves to the biochemical
inhibition data in ``data/assay_data.csv`` and report IC50, Hill slope and
goodness of fit for each assay.

The CSV is tidy/long with columns:
    assay, compound, concentration_uM, replicate, pct_inhibition

Usage
-----
    python scripts/ic50_analysis.py
    python scripts/ic50_analysis.py --assay WRN_ATPase --plot

Dependencies: numpy, pandas, scipy (matplotlib only for --plot).

NOTE: This is simulated, fictional data for a role-play scenario. NPX-2137
and Project Meridian are not real compounds/programs.
"""
from __future__ import annotations

import argparse
import os
from dataclasses import dataclass

import numpy as np
import pandas as pd
from scipy.optimize import curve_fit

DATA = os.path.join(os.path.dirname(__file__), "..", "data", "assay_data.csv")


def four_pl(x, bottom, top, ic50, hill):
    """4-parameter logistic. x is concentration (uM); returns % inhibition."""
    return bottom + (top - bottom) / (1.0 + (ic50 / x) ** hill)


@dataclass
class FitResult:
    assay: str
    ic50_uM: float
    ic50_nM: float
    hill: float
    top: float
    bottom: float
    r2: float
    n: int

    def __str__(self) -> str:
        unit = f"{self.ic50_nM:6.1f} nM" if self.ic50_uM < 1 else f"{self.ic50_uM:6.3f} uM"
        return (
            f"{self.assay:<20s}  IC50 = {unit}   "
            f"Hill = {self.hill:4.2f}   "
            f"top = {self.top:5.1f}%   R^2 = {self.r2:5.3f}   (n={self.n})"
        )


def fit_assay(df: pd.DataFrame, assay: str) -> FitResult:
    sub = df[df["assay"] == assay]
    x = sub["concentration_uM"].to_numpy(dtype=float)
    y = sub["pct_inhibition"].to_numpy(dtype=float)

    # Sensible starting guesses + bounds keep the optimizer well-behaved.
    p0 = [0.0, 100.0, np.median(x), 1.0]
    bounds = ([-20, 50, x.min() / 10, 0.3], [20, 120, x.max() * 10, 4.0])
    popt, _ = curve_fit(four_pl, x, y, p0=p0, bounds=bounds, maxfev=20000)
    bottom, top, ic50, hill = popt

    resid = y - four_pl(x, *popt)
    ss_res = float(np.sum(resid ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = 1.0 - ss_res / ss_tot if ss_tot else float("nan")

    return FitResult(assay, ic50, ic50 * 1000.0, hill, top, bottom, r2, len(sub))


def main() -> None:
    ap = argparse.ArgumentParser(description="4PL IC50 fitting for NPX-2137 assays")
    ap.add_argument("--assay", help="restrict to a single assay name")
    ap.add_argument("--plot", action="store_true", help="show fitted curves")
    args = ap.parse_args()

    df = pd.read_csv(DATA)
    assays = [args.assay] if args.assay else sorted(df["assay"].unique())

    print(f"IC50 analysis  --  {len(df)} data points across {len(assays)} assay(s)\n")
    results = [fit_assay(df, a) for a in assays]
    for r in results:
        print("  " + str(r))

    # Selectivity summary relative to the primary (WRN_ATPase) target.
    primary = next((r for r in results if r.assay == "WRN_ATPase"), None)
    if primary and len(results) > 1:
        print("\nSelectivity vs WRN_ATPase:")
        for r in results:
            if r is primary:
                continue
            print(f"  {r.assay:<20s}  {r.ic50_uM / primary.ic50_uM:5.1f}x")

    if args.plot:
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(6, 4))
        xx = np.logspace(-3, 1, 200)
        for a in assays:
            r = fit_assay(df, a)
            sub = df[df["assay"] == a]
            ax.scatter(sub["concentration_uM"], sub["pct_inhibition"], s=14, alpha=0.6)
            ax.plot(xx, four_pl(xx, r.bottom, r.top, r.ic50_uM, r.hill), label=f"{a} (IC50 {r.ic50_nM:.0f} nM)")
        ax.set_xscale("log")
        ax.set_xlabel("Concentration (uM)")
        ax.set_ylabel("% inhibition")
        ax.set_title("NPX-2137 biochemical dose-response")
        ax.legend(fontsize=8)
        fig.tight_layout()
        plt.show()


if __name__ == "__main__":
    main()
