#!/usr/bin/env python3
"""
smiles_utils.py  --  Project Meridian / NPX-2137

Lightweight molecule / SMILES utilities for the discovery team: compute
molecular descriptors and evaluate drug-likeness rules (Lipinski Ro5,
Veber) for the lead series.

Two backends:
  * If RDKit is installed, descriptors are computed rigorously from SMILES.
  * Otherwise a small built-in fallback returns the curated reference
    descriptors for known series members so the module still runs in a
    bare environment (useful for CI / quick checks).

Usage
-----
    python scripts/smiles_utils.py                 # profile the lead, NPX-2137
    python scripts/smiles_utils.py --smiles "CCO"  # profile an arbitrary SMILES

NOTE: NPX-2137 is a fictional compound; the SMILES below is illustrative and
was constructed to match the target physicochemical profile for a role-play.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass, asdict

# Fictional lead structure (illustrative).
NPX_2137_SMILES = "Cc1nc(Nc2cccc(S(C)(=O)=O)c2)nc(N2CCN(C(=O)c3ccc(F)cc3)CC2)n1"

# Curated reference descriptors used by the RDKit-free fallback path.
_REFERENCE = {
    NPX_2137_SMILES: dict(
        name="NPX-2137", formula="C21H24FN5O2S", mw=429.51,
        clogp=2.8, tpsa=92.0, hbd=2, hba=6, rotatable_bonds=5, aromatic_rings=3,
    ),
}


@dataclass
class MolProfile:
    name: str
    smiles: str
    formula: str
    mw: float
    clogp: float
    tpsa: float
    hbd: int
    hba: int
    rotatable_bonds: int
    aromatic_rings: int

    # ---- drug-likeness rules ----
    def lipinski(self) -> dict:
        checks = {
            "MW <= 500": self.mw <= 500,
            "cLogP <= 5": self.clogp <= 5,
            "HBD <= 5": self.hbd <= 5,
            "HBA <= 10": self.hba <= 10,
        }
        violations = sum(1 for ok in checks.values() if not ok)
        return {"checks": checks, "violations": violations, "pass": violations <= 1}

    def veber(self) -> dict:
        checks = {"RotB <= 10": self.rotatable_bonds <= 10, "TPSA <= 140": self.tpsa <= 140}
        return {"checks": checks, "pass": all(checks.values())}


def _try_rdkit(smiles: str, name: str) -> MolProfile | None:
    try:
        from rdkit import Chem
        from rdkit.Chem import Descriptors, rdMolDescriptors, Crippen
    except Exception:
        return None
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"RDKit could not parse SMILES: {smiles!r}")
    return MolProfile(
        name=name,
        smiles=smiles,
        formula=rdMolDescriptors.CalcMolFormula(mol),
        mw=round(Descriptors.MolWt(mol), 2),
        clogp=round(Crippen.MolLogP(mol), 2),
        tpsa=round(rdMolDescriptors.CalcTPSA(mol), 1),
        hbd=rdMolDescriptors.CalcNumHBD(mol),
        hba=rdMolDescriptors.CalcNumHBA(mol),
        rotatable_bonds=rdMolDescriptors.CalcNumRotatableBonds(mol),
        aromatic_rings=rdMolDescriptors.CalcNumAromaticRings(mol),
    )


def profile(smiles: str = NPX_2137_SMILES, name: str = "NPX-2137") -> MolProfile:
    """Return a MolProfile for ``smiles`` (RDKit if available, else fallback)."""
    prof = _try_rdkit(smiles, name)
    if prof is not None:
        return prof
    ref = _REFERENCE.get(smiles)
    if ref is None:
        raise RuntimeError(
            "RDKit is not installed and no reference descriptors exist for this "
            "SMILES. Install rdkit (`pip install rdkit`) to profile new structures."
        )
    return MolProfile(smiles=smiles, **ref)


def _print_report(p: MolProfile) -> None:
    print(f"\n{p.name}   {p.formula}   ({p.smiles})")
    print("-" * 68)
    for k, v in asdict(p).items():
        if k in ("name", "smiles", "formula"):
            continue
        print(f"  {k:<18s} {v}")

    ro5 = p.lipinski()
    print("\n  Lipinski Rule of 5:")
    for label, ok in ro5["checks"].items():
        print(f"    [{'PASS' if ok else 'FAIL'}] {label}")
    print(f"    -> {ro5['violations']} violation(s); "
          f"{'PASS' if ro5['pass'] else 'FAIL'}")

    veber = p.veber()
    print("\n  Veber:")
    for label, ok in veber["checks"].items():
        print(f"    [{'PASS' if ok else 'FAIL'}] {label}")
    print(f"    -> {'PASS' if veber['pass'] else 'FAIL'}\n")


def main() -> None:
    ap = argparse.ArgumentParser(description="Molecular descriptor / drug-likeness profiler")
    ap.add_argument("--smiles", default=NPX_2137_SMILES, help="SMILES to profile")
    ap.add_argument("--name", default="NPX-2137", help="display name")
    args = ap.parse_args()
    _print_report(profile(args.smiles, args.name))


if __name__ == "__main__":
    main()
