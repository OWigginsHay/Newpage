#!/usr/bin/env python3
"""
plot_charts.py  --  Project Meridian / NPX-2137

Regenerate the figures used in the NPX-2137 Discovery Report from the source
CSVs in ``data/``. Saves PNGs to ``figures/`` (created if absent).

Figures
-------
    fig1_dose_response.png   biochemical 4PL curves (assay_data.csv)
    fig2_cell_gi50.png       antiproliferative GI50 bar chart (cell_potency.csv)
    fig3_pk.png              rat plasma concentration-time (study_data.csv)
    fig4_xenograft.png       HCT116 xenograft tumor growth (study_data.csv)

Usage
-----
    python scripts/plot_charts.py
    python scripts/plot_charts.py --show

Dependencies: numpy, pandas, matplotlib, scipy.

Brand palette matches the Newpage design system used in the report.

NOTE: simulated, fictional data for a role-play scenario.
"""
from __future__ import annotations

import argparse
import os

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from ic50_analysis import fit_assay, four_pl  # reuse the 4PL fit

HERE = os.path.dirname(__file__)
DATA = os.path.join(HERE, "..", "data")
OUT = os.path.join(HERE, "..", "figures")

# --- Newpage brand palette -------------------------------------------------
TEAL = "#08BDB8"
TEAL_DARK = "#008C85"
ORANGE = "#FF7F1F"
YELLOW = "#FFCF36"
GREY = "#68767A"
INK = "#0C1213"


def _style(ax):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, color="#DDE3E4", linewidth=0.8)
    ax.set_axisbelow(True)


def fig_dose_response(save, show):
    df = pd.read_csv(os.path.join(DATA, "assay_data.csv"))
    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    xx = np.logspace(-3, 1, 200)
    colors = {"WRN_ATPase": TEAL, "WRN_DNA_unwinding": ORANGE}
    for assay, color in colors.items():
        r = fit_assay(df, assay)
        sub = df[df["assay"] == assay]
        ax.scatter(sub["concentration_uM"], sub["pct_inhibition"], s=16, color=color, alpha=0.55, zorder=3)
        ax.plot(xx, four_pl(xx, r.bottom, r.top, r.ic50_uM, r.hill),
                color=color, lw=2.4, label=f"{assay.replace('_', ' ')} - IC50 {r.ic50_nM:.0f} nM")
    ax.set_xscale("log")
    ax.set_xlabel("Concentration (uM)")
    ax.set_ylabel("% inhibition")
    ax.set_title("Fig 1 - NPX-2137 biochemical dose-response", loc="left", fontweight="bold")
    ax.legend(fontsize=8, frameon=True)
    _style(ax)
    _finish(fig, "fig1_dose_response.png", save, show)


def fig_cell_gi50(save, show):
    df = pd.read_csv(os.path.join(DATA, "cell_potency.csv"))
    df = df.sort_values("gi50_uM")
    colors = [TEAL if "MSI-H" in s and "KO" not in s else GREY for s in df["msi_status"]]
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    y = np.arange(len(df))
    ax.barh(y, -np.log10(df["gi50_uM"]), color=colors, height=0.62, zorder=3)
    ax.set_yticks(y)
    ax.set_yticklabels(df["cell_line"])
    for yi, (gi, cen) in enumerate(zip(df["gi50_uM"], df["censored"])):
        lab = f">10 uM" if cen else f"{gi:.2f} uM"
        ax.text(-np.log10(gi) + 0.05, yi, lab, va="center", fontsize=8)
    ax.set_xlabel("-log10 GI50  (longer = more potent)")
    ax.set_title("Fig 2 - antiproliferative potency (72 h)", loc="left", fontweight="bold")
    _style(ax)
    ax.grid(axis="y", visible=False)
    _finish(fig, "fig2_cell_gi50.png", save, show)


def fig_pk(save, show):
    df = pd.read_csv(os.path.join(DATA, "study_data.csv"))
    pk = df[df["study"] == "pk_rat_5mgkg_po"]
    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    ax.errorbar(pk["x_value"], pk["y_value"], yerr=pk["y_error"], color=TEAL,
                lw=2.4, marker="o", ms=5, capsize=3, zorder=3)
    ax.set_xlabel("Time (h)")
    ax.set_ylabel("Plasma conc. (ng/mL)")
    ax.set_title("Fig 3 - rat PK, 5 mg/kg PO", loc="left", fontweight="bold")
    _style(ax)
    _finish(fig, "fig3_pk.png", save, show)


def fig_xenograft(save, show):
    df = pd.read_csv(os.path.join(DATA, "study_data.csv"))
    xg = df[df["study"] == "xenograft_HCT116"]
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    palette = {"Vehicle": GREY, "NPX-2137_25mgkg": ORANGE, "NPX-2137_50mgkg": TEAL}
    for group, color in palette.items():
        g = xg[xg["group"] == group]
        ax.errorbar(g["x_value"], g["y_value"], yerr=g["y_error"], color=color,
                    lw=2.4, marker="o", ms=4, capsize=2.5,
                    label=group.replace("_", " "), zorder=3)
    ax.set_xlabel("Days of dosing")
    ax.set_ylabel("Tumor volume (mm3)")
    ax.set_title("Fig 4 - HCT116 xenograft (mean +/- SEM)", loc="left", fontweight="bold")
    ax.legend(fontsize=8)
    _style(ax)
    _finish(fig, "fig4_xenograft.png", save, show)


def _finish(fig, name, save, show):
    fig.tight_layout()
    if save:
        os.makedirs(OUT, exist_ok=True)
        path = os.path.join(OUT, name)
        fig.savefig(path, dpi=150)
        print(f"  wrote {os.path.relpath(path)}")
    if show:
        plt.show()
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser(description="Regenerate NPX-2137 report figures")
    ap.add_argument("--show", action="store_true", help="display interactively")
    ap.add_argument("--no-save", action="store_true", help="do not write PNGs")
    args = ap.parse_args()
    save = not args.no_save
    print("Generating figures...")
    fig_dose_response(save, args.show)
    fig_cell_gi50(save, args.show)
    fig_pk(save, args.show)
    fig_xenograft(save, args.show)
    print("Done.")


if __name__ == "__main__":
    main()
